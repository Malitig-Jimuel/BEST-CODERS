const mysql = require("mysql2");

const db = mysql.createPool({
  host: "localhost",
  port: 3307,      // Your XAMPP MySQL port
  user: "root",
  password: "",
  database: "lostandfound_db"
});

db.getConnection((err, connection) => {
  if (err) throw err;
  console.log("MySQL connected");
  connection.release();
});

module.exports = db;
