const express = require("express");
const app = express();
app.use(express.json());

// Import routes
const userRoutes = require("./routes/userRoutes");
const locationRoutes = require("./routes/locationRoutes");
const itemRoutes = require("./routes/itemRoutes");
const claimantRoutes = require("./routes/claimantRoutes");
const claimRoutes = require("./routes/claimRoutes");

// Use routes
app.use("/api/users", userRoutes);
app.use("/api/locations", locationRoutes);
app.use("/api/items", itemRoutes);
app.use("/api/claimants", claimantRoutes);
app.use("/api/claims", claimRoutes);

// Test route
app.get("/", (req, res) => res.send("Server is running!"));

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
