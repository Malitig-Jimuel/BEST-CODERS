const itemModel = require("../models/itemModel");

const addItem = (req, res) => {
  const { item_name, description, date_found, status, location_id, added_by } = req.body;
  if (!item_name || !date_found || !location_id || !added_by) return res.status(400).json({ error: "Missing required fields" });

  itemModel.addItem(req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Item added", itemId: result.insertId });
  });
};

const getAllItems = (req, res) => itemModel.getAllItems((err, results) => {
  if (err) return res.status(500).json({ error: err.message });
  res.json(results);
});

const getItemById = (req, res) => {
  const id = req.params.id;
  itemModel.getItemById(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.length === 0) return res.status(404).json({ error: "Item not found" });
    res.json(result[0]);
  });
};

const updateItem = (req, res) => {
  const id = req.params.id;
  itemModel.updateItem(id, req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Item updated" });
  });
};

const markAsClaimed = (req, res) => {
  const id = req.params.id;
  itemModel.markAsClaimed(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Item marked as claimed" });
  });
};

module.exports = { addItem, getAllItems, getItemById, updateItem, markAsClaimed };
