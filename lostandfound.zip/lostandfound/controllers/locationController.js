const locationModel = require("../models/locationModel");

const addLocation = (req, res) => {
  const { location_name, building, room_number } = req.body;
  if (!location_name) return res.status(400).json({ error: "Location name is required" });
  locationModel.addLocation(req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Location added", locationId: result.insertId });
  });
};

const getAllLocations = (req, res) => {
  locationModel.getAllLocations((err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const getLocationById = (req, res) => {
  const id = req.params.id;
  locationModel.getLocationById(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.length === 0) return res.status(404).json({ error: "Location not found" });
    res.json(result[0]);
  });
};

const updateLocation = (req, res) => {
  const id = req.params.id;
  locationModel.updateLocation(id, req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Location updated" });
  });
};

const removeLocation = (req, res) => {
  const id = req.params.id;
  locationModel.removeLocation(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Location deleted" });
  });
};

module.exports = { addLocation, getAllLocations, getLocationById, updateLocation, removeLocation };
