const userModel = require("../models/userModel");

const addUser = (req, res) => {
  const { username, password, name, role } = req.body;
  if (!username || !password || !role)
    return res.status(400).json({ error: "Missing required fields" });

  userModel.addUser(req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "User added", userId: result.insertId });
  });
};

const getAllUsers = (req, res) => {
  userModel.getAllUsers((err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const getUserById = (req, res) => {
  const id = req.params.id;
  userModel.getUserById(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.length === 0) return res.status(404).json({ error: "User not found" });
    res.json(result[0]);
  });
};

const updateUser = (req, res) => {
  const id = req.params.id;
  userModel.updateUser(id, req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "User updated" });
  });
};

const removeUser = (req, res) => {
  const id = req.params.id;
  userModel.removeUser(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "User deleted" });
  });
};

module.exports = { addUser, getAllUsers, getUserById, updateUser, removeUser };
