const claimModel = require("../models/claimModel");

const addClaim = (req, res) => {
  const { item_id, claimant_id, verified_by, date_claimed } = req.body;
  if (!item_id || !claimant_id || !date_claimed) 
    return res.status(400).json({ error: "Missing required fields" });

  claimModel.addClaim(req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Claim added", claimId: result.insertId });
  });
};

const getAllClaims = (req, res) => {
  claimModel.getAllClaims((err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

const getClaimById = (req, res) => {
  const id = req.params.id;
  claimModel.getClaimById(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.length === 0) return res.status(404).json({ error: "Claim not found" });
    res.json(result[0]);
  });
};

const updateClaim = (req, res) => {
  const id = req.params.id;
  claimModel.updateClaim(id, req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Claim updated" });
  });
};

const verifyClaim = (req, res) => {
  const id = req.params.id;
  claimModel.verifyClaim(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Claim verified" });
  });
};

module.exports = { addClaim, getAllClaims, getClaimById, updateClaim, verifyClaim };
