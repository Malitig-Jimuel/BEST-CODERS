const claimantModel = require("../models/claimantModel");

const addClaimant = (req, res) => {
  const { claimant_name, contact_number, email } = req.body;
  if (!claimant_name) return res.status(400).json({ error: "Claimant name is required" });

  claimantModel.addClaimant(req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Claimant added", claimantId: result.insertId });
  });
};

const getAllClaimants = (req, res) => claimantModel.getAllClaimants((err, results) => {
  if (err) return res.status(500).json({ error: err.message });
  res.json(results);
});

const getClaimantById = (req, res) => {
  const id = req.params.id;
  claimantModel.getClaimantById(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    if (result.length === 0) return res.status(404).json({ error: "Claimant not found" });
    res.json(result[0]);
  });
};

const updateClaimant = (req, res) => {
  const id = req.params.id;
  claimantModel.updateClaimant(id, req.body, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Claimant updated" });
  });
};

const removeClaimant = (req, res) => {
  const id = req.params.id;
  claimantModel.removeClaimant(id, (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Claimant deleted" });
  });
};

module.exports = { addClaimant, getAllClaimants, getClaimantById, updateClaimant, removeClaimant };
