const express = require("express");
const router = express.Router();
const claimantController = require("../controllers/claimantController");

router.post("/", claimantController.addClaimant);
router.get("/", claimantController.getAllClaimants);
router.get("/:id", claimantController.getClaimantById);
router.put("/:id", claimantController.updateClaimant);
router.delete("/removed/:id", claimantController.removeClaimant);

module.exports = router;
