const express = require("express");
const router = express.Router();
const claimController = require("../controllers/claimController");

router.post("/", claimController.addClaim);
router.get("/", claimController.getAllClaims);
router.get("/:id", claimController.getClaimById);
router.put("/:id", claimController.updateClaim);
router.put("/verify/:id", claimController.verifyClaim);

module.exports = router;
