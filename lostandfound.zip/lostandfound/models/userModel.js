const db = require("../database");

const addUser = (data, callback) => {
  const { username, password, name, role } = data;
  db.query(
    "INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)",
    [username, password, name, role],
    callback
  );
};

const getAllUsers = (callback) =>
  db.query("SELECT user_id, username, name, role FROM users", callback);

const getUserById = (id, callback) =>
  db.query("SELECT user_id, username, name, role FROM users WHERE user_id = ?", [id], callback);

const updateUser = (id, data, callback) => {
  const { name, password, role } = data;
  db.query("UPDATE users SET name = ?, password = ?, role = ? WHERE user_id = ?", [name, password, role, id], callback);
};

const removeUser = (id, callback) =>
  db.query("DELETE FROM users WHERE user_id = ?", [id], callback);

module.exports = { addUser, getAllUsers, getUserById, updateUser, removeUser };
