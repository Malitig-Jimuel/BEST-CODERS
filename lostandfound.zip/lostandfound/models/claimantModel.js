const db = require("../database");

const addClaimant = (data, callback) => {
  const { claimant_name, contact_number, email } = data;
  db.query(
    "INSERT INTO claimants (claimant_name, contact_number, email) VALUES (?, ?, ?)",
    [claimant_name, contact_number, email],
    callback
  );
};

const getAllClaimants = (callback) => db.query("SELECT * FROM claimants", callback);
const getClaimantById = (id, callback) => db.query("SELECT * FROM claimants WHERE claimant_id = ?", [id], callback);
const updateClaimant = (id, data, callback) => {
  const { claimant_name, contact_number, email } = data;
  db.query("UPDATE claimants SET claimant_name = ?, contact_number = ?, email = ? WHERE claimant_id = ?", [claimant_name, contact_number, email, id], callback);
};
const removeClaimant = (id, callback) => db.query("DELETE FROM claimants WHERE claimant_id = ?", [id], callback);

module.exports = { addClaimant, getAllClaimants, getClaimantById, updateClaimant, removeClaimant };
