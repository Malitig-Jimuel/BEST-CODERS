const db = require("../database");

const addItem = (data, callback) => {
  const { item_name, description, date_found, status, location_id, added_by } = data;
  db.query(
    "INSERT INTO items (item_name, description, date_found, status, location_id, added_by) VALUES (?, ?, ?, ?, ?, ?)",
    [item_name, description, date_found, status, location_id, added_by],
    callback
  );
};

const getAllItems = (callback) => db.query("SELECT * FROM items", callback);

const getItemById = (id, callback) => db.query("SELECT * FROM items WHERE item_id = ?", [id], callback);

const updateItem = (id, data, callback) => {
  const { item_name, description, date_found, status, location_id } = data;
  db.query(
    "UPDATE items SET item_name = ?, description = ?, date_found = ?, status = ?, location_id = ? WHERE item_id = ?",
    [item_name, description, date_found, status, location_id, id],
    callback
  );
};

const markAsClaimed = (id, callback) => {
  db.query("UPDATE items SET status = 'Claimed' WHERE item_id = ?", [id], callback);
};

module.exports = { addItem, getAllItems, getItemById, updateItem, markAsClaimed };
