const db = require("../database");

const addLocation = (data, callback) => {
  const { location_name, building, room_number } = data;
  db.query(
    "INSERT INTO locations (location_name, building, room_number) VALUES (?, ?, ?)",
    [location_name, building, room_number],
    callback
  );
};

const getAllLocations = (callback) =>
  db.query("SELECT * FROM locations", callback);

const getLocationById = (id, callback) =>
  db.query("SELECT * FROM locations WHERE location_id = ?", [id], callback);

const updateLocation = (id, data, callback) => {
  const { location_name, building, room_number } = data;
  db.query(
    "UPDATE locations SET location_name = ?, building = ?, room_number = ? WHERE location_id = ?",
    [location_name, building, room_number, id],
    callback
  );
};

const removeLocation = (id, callback) =>
  db.query("DELETE FROM locations WHERE location_id = ?", [id], callback);

module.exports = { addLocation, getAllLocations, getLocationById, updateLocation, removeLocation };
