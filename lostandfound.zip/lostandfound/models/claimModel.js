const db = require("../database");

const addClaim = (data, callback) => {
  const { item_id, claimant_id, verified_by, date_claimed } = data;
  db.query(
    "INSERT INTO claims (item_id, claimant_id, verified_by, date_claimed) VALUES (?, ?, ?, ?)",
    [item_id, claimant_id, verified_by, date_claimed],
    callback
  );
};

const getAllClaims = (callback) => db.query("SELECT * FROM claims", callback);
const getClaimById = (id, callback) => db.query("SELECT * FROM claims WHERE claim_id = ?", [id], callback);
const updateClaim = (id, data, callback) => {
  const { item_id, claimant_id, verified_by, date_claimed } = data;
  db.query("UPDATE claims SET item_id = ?, claimant_id = ?, verified_by = ?, date_claimed = ? WHERE claim_id = ?", [item_id, claimant_id, verified_by, date_claimed, id], callback);
};
const verifyClaim = (id, callback) => {
  db.query("UPDATE claims SET verified_by = verified_by WHERE claim_id = ?", [id], callback); // update as verified
};

module.exports = { addClaim, getAllClaims, getClaimById, updateClaim, verifyClaim };
